# Widgetology — Flutter Project

## Project Structure
```
lib/
├── main.dart                        # App entry, edge-to-edge setup
├── theme/
│   └── app_theme.dart               # AppColors, AppGradients, AppTheme
├── models/
│   └── widget_model.dart            # WidgetModel, WidgetCategory, seed data
├── widgets/  (shared UI components)
│   ├── glass_components.dart        # GlassBox, SectionLabel, TierBadge, StarRating, GradientText, PressableScale
│   └── widget_card.dart             # WidgetCard (normal + wide layouts)
└── screens/
    ├── home_screen.dart             # Main explore screen
    └── widget_detail_screen.dart    # Detail + size selector + CTA
```

## Setup

```bash
flutter pub get
flutter run
```

## How to Add a New Widget

### 1. Register it in `widget_model.dart`
```dart
const WidgetModel(
  id: 'my_new_widget',
  name: 'My Widget',
  subtitle: 'Does something cool',
  emoji: '🌙',
  tier: WidgetTier.free,   // or WidgetTier.pro
  category: WidgetCategory.clocks,
  rating: 4.8,
  reviewCount: 100,
  price: null,             // null = free, '\$1.99' = paid
  tags: ['clock', 'dark'],
  cardColor: WidgetCardColor.purple,
),
```

### 2. Add a live preview in `widget_card.dart`
Inside `_PreviewSlot.build()`, add a case:
```dart
if (widget.id == 'my_new_widget') return MyWidgetPreview();
```

### 3. Add the real Android home-screen widget
- Create `android/app/src/main/res/xml/my_widget_info.xml`
- Create `android/app/src/main/res/layout/my_widget.xml`
- Register a `<receiver>` in `AndroidManifest.xml` (see android_manifest_readme.xml)
- Use `home_widget` package to push data from Flutter to the widget

## Free vs Paid
- `WidgetTier.free` → green FREE badge, no paywall
- `WidgetTier.pro` → yellow PRO badge + price shown in CTA button
- Implement payment via `in_app_purchase` package (not yet wired)

## Android 11+ Edge-to-Edge
Already configured in `main.dart`:
- `SystemUiMode.edgeToEdge`
- Transparent status bar + nav bar
- `enableOnBackInvokedCallback` in manifest
