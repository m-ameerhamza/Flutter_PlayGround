import 'package:flutter_test/flutter_test.dart';

import 'package:widgetology/main.dart';

void main() {
  testWidgets('renders redesigned home screen and Me entry point', (tester) async {
    await tester.pumpWidget(const WidgetologyApp());
    await tester.pumpAndSettle();

    expect(find.text('Widgetology'), findsOneWidget);
    expect(find.text('Me'), findsOneWidget);
    expect(find.text('Browse widgets'), findsOneWidget);
  });
}
