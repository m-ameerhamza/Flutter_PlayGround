import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/widget_model.dart';
import '../state/widget_store.dart';
import '../theme/app_theme.dart';
import '../widgets/digital_clock_widget.dart';
import '../widgets/glass_components.dart';
import '../widgets/widget_card.dart';
import 'widget_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  WidgetCategory _selectedCategory = WidgetCategory.clocks;

  @override
  Widget build(BuildContext context) {
    final store = WidgetStoreScope.of(context);
    final widgets = kWidgets
        .where((widget) => widget.category == _selectedCategory)
        .toList();
    final freeWidgets = widgets.where((widget) => widget.isFree).toList();
    final paidWidgets = widgets.where((widget) => !widget.isFree).toList();
    final showPlaceholder = _selectedCategory != WidgetCategory.clocks;

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppColors.canvas, AppColors.background],
        ),
      ),
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          children: [
            Text(
              'Widgetology',
              style: GoogleFonts.spaceGrotesk(
                fontSize: 30,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
'Browse widgets, install them, and add them to your Android home screen.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 20),
            _HomePreviewCard(store: store),
            const SizedBox(height: 22),
            Text('Categories', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            _CategorySelector(
              selectedCategory: _selectedCategory,
              onSelected: (category) =>
                  setState(() => _selectedCategory = category),
            ),
            const SizedBox(height: 22),
            if (showPlaceholder) ...[
              const _ComingSoonCard(),
            ] else ...[
              _WidgetSection(
                title: 'Free Widgets',
                widgets: freeWidgets,
                emptyLabel: 'No free widgets yet.',
              ),
              const SizedBox(height: 20),
              _WidgetSection(
                title: 'Paid Widgets',
                widgets: paidWidgets,
                emptyLabel: 'No paid widgets yet.',
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _HomePreviewCard extends StatelessWidget {
  const _HomePreviewCard({required this.store});

  final WidgetStore store;

  @override
  Widget build(BuildContext context) {
    final homeWidgets = store.homeWidgets;
    final accent = store.clockColor.swatch;

    return GlassBox(
      gradient: AppGradients.hero,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
'Widget Preview',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
  Text(
    homeWidgets.isEmpty
        ? 'Add a widget from the store to see it here.'
        : '${homeWidgets.length} widget${homeWidgets.length == 1 ? '' : 's'} ready for your Android home screen.',
    style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.8),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  store.use24HourClock ? '24-hour' : '12-hour',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: AppColors.navy,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.74),
              borderRadius: BorderRadius.circular(28),
            ),
            child: homeWidgets.isEmpty
                ? _EmptyPreview(accent: accent)
                : Wrap(
                    spacing: 14,
                    runSpacing: 14,
                    children: homeWidgets.map((widget) {
                      return SizedBox(
                        width: 280,
                        child: DigitalClockWidgetPreview(
                          accent: accent,
                          use24HourClock: store.use24HourClock,
                          compactLayout: store.compactClockLayout,
                          style: store.clockStyle,
                          showSeconds: true,
                          padding: const EdgeInsets.all(18),
                        ),
                      );
                    }).toList(),
                  ),
          ),
        ],
      ),
    );
  }
}

class _EmptyPreview extends StatelessWidget {
  const _EmptyPreview({required this.accent});

  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.canvas,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.borderSoft),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(Icons.add_box_outlined, color: accent),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              'No widgets added yet. Open a widget and choose "Add to Home Screen".',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}

class _CategorySelector extends StatelessWidget {
  const _CategorySelector({
    required this.selectedCategory,
    required this.onSelected,
  });

  final WidgetCategory selectedCategory;
  final ValueChanged<WidgetCategory> onSelected;

  @override
  Widget build(BuildContext context) {
    final categories = [WidgetCategory.clocks, WidgetCategory.music];

    return SizedBox(
      height: 52,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, _) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final category = categories[index];
          final selected = category == selectedCategory;

          return GestureDetector(
            onTap: () => onSelected(category),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              decoration: BoxDecoration(
                color: selected ? AppColors.navy : AppColors.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: selected ? AppColors.navy : AppColors.borderSoft,
                ),
              ),
              child: Text(
                category.label,
                style: TextStyle(
                  color: selected ? Colors.white : AppColors.textSecondary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _WidgetSection extends StatelessWidget {
  const _WidgetSection({
    required this.title,
    required this.widgets,
    required this.emptyLabel,
  });

  final String title;
  final List<WidgetModel> widgets;
  final String emptyLabel;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        if (widgets.isEmpty)
          GlassBox(
            padding: const EdgeInsets.all(18),
            child: Text(
              emptyLabel,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          )
        else
          Column(
            children: widgets.map((widget) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: WidgetCard(
                  widget: widget,
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => WidgetDetailScreen(widget: widget),
                      ),
                    );
                  },
                ),
              );
            }).toList(),
          ),
      ],
    );
  }
}

class _ComingSoonCard extends StatelessWidget {
  const _ComingSoonCard();

  @override
  Widget build(BuildContext context) {
    return GlassBox(
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'No widgets available yet. Coming soon.',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          Text(
            'This category is ready for future widgets without changing the overall structure.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}
