import 'package:flutter/material.dart';

import '../models/widget_model.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_components.dart';

class PaymentMockScreen extends StatelessWidget {
  const PaymentMockScreen({super.key, required this.widget});

  final WidgetModel widget;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mock Payment')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          GlassBox(
            gradient: AppGradients.hero,
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Checkout preview',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 10),
                Text(
                  'This is a polished mock payment flow so you can demo the premium purchase experience before wiring a real gateway.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.88),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: widget.cardColor.swatch.withValues(
                            alpha: 0.14,
                          ),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Center(
                          child: Icon(
                            widget.icon,
                            size: 28,
                            color: widget.cardColor.swatch,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.name,
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              widget.subtitle,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                      Text(
                        widget.price ?? 'Free',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const SectionLabel('Payment Method'),
          GlassBox(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                _mockField('Cardholder', 'Ameer Khan'),
                const SizedBox(height: 14),
                _mockField('Card number', '4242 4242 4242 4242'),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(child: _mockField('Expiry', '12/28')),
                    const SizedBox(width: 14),
                    Expanded(child: _mockField('CVV', '123')),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const SectionLabel('Order Summary'),
          GlassBox(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                _summaryRow('Widget price', widget.price ?? '\$40.00'),
                const SizedBox(height: 14),
                _summaryRow('Platform fee', '\$0.00'),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  child: Divider(height: 1),
                ),
                _summaryRow('Total', widget.price ?? '\$40.00', strong: true),
              ],
            ),
          ),
          const SizedBox(height: 28),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.navy,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 18),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(22),
              ),
            ),
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(
              'Pay ${widget.price ?? ''}',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }

  Widget _mockField(String label, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: AppColors.canvas,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textMuted,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool strong = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: strong ? AppColors.textPrimary : AppColors.textSecondary,
            fontWeight: strong ? FontWeight.w800 : FontWeight.w700,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: AppColors.textPrimary,
            fontWeight: strong ? FontWeight.w800 : FontWeight.w700,
          ),
        ),
      ],
    );
  }
}
