import 'package:flutter/material.dart';

import '../models/widget_model.dart';
import '../state/widget_store.dart';
import '../theme/app_theme.dart';
import '../widgets/digital_clock_widget.dart';
import '../widgets/glass_components.dart';
import 'widget_detail_screen.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = WidgetStoreScope.of(context);

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppColors.background, AppColors.canvas],
        ),
      ),
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          children: [
            Text('Me', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text(
'Manage downloaded, purchased, and home screen widgets.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 20),
            _StatsRow(store: store),
            const SizedBox(height: 22),
            Text(
              'Downloaded Widgets',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            WidgetCollectionList(
              widgets: store.downloadedWidgets,
              emptyTitle: 'No downloads yet',
              emptySubtitle:
                  'Install a widget from Home and it will appear here.',
              onWidgetTap: (widget) {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => WidgetDetailScreen(widget: widget),
                  ),
                );
              },
            ),
            const SizedBox(height: 22),
            Text(
              'Purchased Widgets',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            WidgetCollectionList(
              widgets: store.purchasedWidgets,
              emptyTitle: 'No purchases yet',
              emptySubtitle: 'Paid widgets will be listed here after checkout.',
              onWidgetTap: (widget) {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => WidgetDetailScreen(widget: widget),
                  ),
                );
              },
            ),
            const SizedBox(height: 22),
            Text(
              'Widget Management',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            _HomeWidgetsManager(store: store),
            const SizedBox(height: 18),
            _CustomizationPanel(store: store),
          ],
        ),
      ),
    );
  }
}

class _StatsRow extends StatelessWidget {
  const _StatsRow({required this.store});

  final WidgetStore store;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _StatCard(
          value: '${store.downloadedWidgets.length}',
          label: 'Downloaded',
        ),
        const SizedBox(width: 12),
        _StatCard(
          value: '${store.purchasedWidgets.length}',
          label: 'Purchased',
        ),
        const SizedBox(width: 12),
        _StatCard(value: '${store.homeWidgets.length}', label: 'On Home'),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GlassBox(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
        child: Column(
          children: [
            Text(value, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class _HomeWidgetsManager extends StatelessWidget {
  const _HomeWidgetsManager({required this.store});

  final WidgetStore store;

  @override
  Widget build(BuildContext context) {
    if (store.homeWidgets.isEmpty) {
      return GlassBox(
        padding: const EdgeInsets.all(20),
        child: Text(
'No widgets added to home screen yet.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      );
    }

    return Column(
      children: store.homeWidgets.map((widget) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GlassBox(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: store.clockColor.swatch.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(widget.icon, color: store.clockColor.swatch),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.name,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 4),
  Text(
                        'Ready for Android home screen',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: () => store.removeWidgetFromHome(widget.id),
                  child: const Text('Remove'),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _CustomizationPanel extends StatelessWidget {
  const _CustomizationPanel({required this.store});

  final WidgetStore store;

  @override
  Widget build(BuildContext context) {
    return GlassBox(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Customize Clock Widget',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 14),
          Text('Clock Format', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 10),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment<bool>(value: false, label: Text('12-hour')),
              ButtonSegment<bool>(value: true, label: Text('24-hour')),
            ],
            selected: {store.use24HourClock},
            onSelectionChanged: (selection) =>
                store.setClockFormat(selection.first),
          ),
          const SizedBox(height: 18),
          Text('Style', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 10),
          SegmentedButton<ClockVisualStyle>(
            segments: const [
              ButtonSegment<ClockVisualStyle>(
                value: ClockVisualStyle.soft,
                label: Text('Soft'),
              ),
              ButtonSegment<ClockVisualStyle>(
                value: ClockVisualStyle.bold,
                label: Text('Bold'),
              ),
            ],
            selected: {store.clockStyle},
            onSelectionChanged: (selection) =>
                store.setClockStyle(selection.first),
          ),
          const SizedBox(height: 18),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: store.compactClockLayout,
            onChanged: store.setCompactClockLayout,
            title: const Text('Compact Layout'),
            subtitle: const Text(
              'Use a tighter widget layout for smaller spaces.',
            ),
          ),
          const SizedBox(height: 8),
          Text('Colors', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: WidgetCardColor.values.map((color) {
              final selected = color == store.clockColor;
              return GestureDetector(
                onTap: () => store.setClockColor(color),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: color.swatch,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: selected ? AppColors.textPrimary : Colors.white,
                      width: selected ? 3 : 1,
                    ),
                  ),
                  child: selected
                      ? const Icon(
                          Icons.check_rounded,
                          color: Colors.white,
                          size: 20,
                        )
                      : null,
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          DigitalClockWidgetPreview(
            accent: store.clockColor.swatch,
            use24HourClock: store.use24HourClock,
            compactLayout: store.compactClockLayout,
            style: store.clockStyle,
            showSeconds: true,
            padding: const EdgeInsets.all(18),
          ),
        ],
      ),
    );
  }
}
