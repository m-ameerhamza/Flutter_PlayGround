import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/widget_model.dart';
import '../services/android_widget_service.dart';
import '../state/widget_store.dart';
import '../theme/app_theme.dart';
import '../widgets/digital_clock_widget.dart';
import '../widgets/glass_components.dart';
import 'payment_mock_screen.dart';

class WidgetDetailScreen extends StatelessWidget {
  const WidgetDetailScreen({super.key, required this.widget});

  final WidgetModel widget;

  @override
  Widget build(BuildContext context) {
    final store = WidgetStoreScope.of(context);
    final accent = store.clockColor.swatch;
    final isDownloaded = store.isDownloaded(widget.id);
    final isPurchased = store.isPurchased(widget.id);
final isReadyForHome = widget.isReadyForHome;
    final isOnHome = store.isAddedToHome(widget.id);

    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          GlassBox(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white, accent.withValues(alpha: 0.14)],
            ),
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: accent.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(widget.icon, size: 30, color: accent),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.name,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            widget.category.label,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    TierBadge(isFree: widget.isFree, price: widget.price),
                  ],
                ),
                const SizedBox(height: 20),
                DigitalClockWidgetPreview(
                  accent: accent,
                  use24HourClock: store.use24HourClock,
                  compactLayout: store.compactClockLayout,
                  style: store.clockStyle,
                  showSeconds: true,
                ),
                const SizedBox(height: 20),
                Text(
                  widget.subtitle,
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'A clean, readable widget built for quick time checks. It supports style changes, color customization, layout adjustments, and 12-hour or 24-hour clock format.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const SectionLabel('Actions'),
          GlassBox(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                _ActionTile(
                  icon: Icons.download_rounded,
                  title: isDownloaded
                      ? 'Installed'
                      : (widget.isFree
                            ? 'Download / Install'
                            : 'Purchase & Install'),
                  subtitle: isDownloaded
                      ? 'This widget is already available in your account.'
                      : widget.isFree
                      ? 'Save this widget to your downloaded list.'
                      : 'Complete checkout to unlock this paid widget.',
                  trailing: FilledButton(
                    onPressed: isDownloaded
                        ? null
                        : () => _handleInstall(context, store),
                    child: Text(
                      isDownloaded
                          ? 'Done'
                          : (widget.isFree ? 'Install' : 'Buy'),
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Divider(height: 1),
                ),
                _ActionTile(
                  icon: Icons.add_to_home_screen_rounded,
                  title: isOnHome
                      ? 'Added to Home Screen'
                      : 'Add to Home Screen',
                  subtitle: isReadyForHome
    ? 'Install this widget on your real Android home screen (long-press home → Widgets → Widgetology).'
                      : 'Install this widget first, then you can add it to your home layout.',
                  trailing: FilledButton.tonal(
                    onPressed: (!isReadyForHome || isOnHome)
                        ? null
                        : () async {
                            // Update the Flutter state first
                            store.addWidgetToHome(widget);
                            // Sync all widgets (legacy clock sync included)
                            unawaited(
                              AndroidWidgetService.syncDigitalClock(
                                use24HourClock: store.use24HourClock,
                                compactLayout: store.compactClockLayout,
                                style: store.clockStyle,
                                color: store.clockColor,
                              ),
                            );
                            final pinned = await AndroidWidgetService.pinDigitalClock();
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  pinned
                                      ? 'Android home screen widget pin request sent'
                                      : 'Widget updated. Long-press home → Widgets → Widgetology to add if not pinned.',
                                ),
                              ),
                            );
                          },
                    child: Text(isOnHome ? 'Added' : 'Add'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const SectionLabel('Widget Details'),
          GlassBox(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                _infoRow('Category', widget.category.label),
                _divider(),
                _infoRow('Availability', widget.isFree ? 'Free' : 'Paid'),
                _divider(),
                _infoRow('Downloaded', isDownloaded ? 'Yes' : 'No'),
                _divider(),
                _infoRow(
                  'Purchased',
                  widget.isFree ? 'Not required' : (isPurchased ? 'Yes' : 'No'),
                ),
                _divider(),
                _infoRow('On Home Preview', isOnHome ? 'Yes' : 'No'),
                _divider(),
                _infoRow(
                  'Clock Format',
                  store.use24HourClock ? '24-hour' : '12-hour',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleInstall(BuildContext context, WidgetStore store) async {
    if (widget.isFree) {
      store.installWidget(widget);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Widget installed')));
      return;
    }

    final purchased = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => PaymentMockScreen(widget: widget)),
    );

    if (purchased == true) {
      store.purchaseWidget(widget);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Purchase complete and widget installed'),
          ),
        );
      }
    }
  }

  Widget _infoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          child: Text(
            label,
            style: const TextStyle(
              color: AppColors.textMuted,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }

  Widget _divider() => const Padding(
    padding: EdgeInsets.symmetric(vertical: 14),
    child: Divider(height: 1),
  );
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.trailing,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: AppColors.canvas,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: AppColors.navy),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
        const SizedBox(width: 12),
        trailing,
      ],
    );
  }
}
