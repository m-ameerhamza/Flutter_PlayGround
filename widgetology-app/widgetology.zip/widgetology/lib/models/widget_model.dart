import 'package:flutter/material.dart';

enum WidgetTier { free, pro }

enum WidgetCategory { all, clocks, music }

enum ClockVisualStyle { soft, bold }

class WidgetModel {
  final String id;
  final String name;
  final String subtitle;
  final IconData icon;
  final WidgetTier tier;
  final WidgetCategory category;
  final double rating;
  final int reviewCount;
  final String? price;
  final bool isInstalled;
  final bool isReadyForHome;
  final List<String> tags;
  final WidgetCardColor cardColor;

  const WidgetModel({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.icon,
    required this.tier,
    required this.category,
    required this.rating,
    required this.reviewCount,
    this.price,
    this.isInstalled = false,
    this.isReadyForHome = true,
    required this.tags,
    required this.cardColor,
  });

  bool get isFree => tier == WidgetTier.free;
}

enum WidgetCardColor { navy, terracotta, gold, sage, rose, sky }

const WidgetModel kStarterClockWidget = WidgetModel(
  id: 'digital_clock',
  name: 'Digital Clock',
  subtitle: 'A clean starter clock widget for your home screen',
  icon: Icons.access_time_rounded,
  tier: WidgetTier.free,
  category: WidgetCategory.clocks,
  rating: 5.0,
  reviewCount: 12,
  tags: ['clock', 'digital', 'starter'],
  cardColor: WidgetCardColor.navy,
  isReadyForHome: true,
);

const List<WidgetModel> kWidgets = [
  kStarterClockWidget,
  WidgetModel(
    id: 'weather',
    name: 'Weather Widget',
    subtitle: 'Current weather on your home screen',
  icon: Icons.wb_cloudy,
    tier: WidgetTier.free,
    category: WidgetCategory.clocks,
    rating: 4.8,
    reviewCount: 28,
    tags: ['weather', 'forecast', 'temp'],
    cardColor: WidgetCardColor.sky,
    isReadyForHome: true,
  ),
  WidgetModel(
    id: 'battery',
    name: 'Battery Widget',
    subtitle: 'Battery status and charging info',
    icon: Icons.battery_full_rounded,
    tier: WidgetTier.free,
    category: WidgetCategory.clocks,
    rating: 4.6,
    reviewCount: 15,
    tags: ['battery', 'power', 'status'],
    cardColor: WidgetCardColor.sage,
    isReadyForHome: true,
  ),
  WidgetModel(
    id: 'music',
    name: 'Music Widget',
    subtitle: 'Control music player from home screen',
    icon: Icons.music_note_rounded,
    tier: WidgetTier.pro,
    category: WidgetCategory.music,
    rating: 4.9,
    reviewCount: 42,
    price: '\$1.99',
    tags: ['music', 'player', 'control'],
    cardColor: WidgetCardColor.rose,
    isReadyForHome: true,
  ),
];

List<WidgetModel> widgetsFromIds(Set<String> ids) {
  return kWidgets.where((widget) => ids.contains(widget.id)).toList();
}

extension WidgetCategoryLabel on WidgetCategory {
  String get label => switch (this) {
    WidgetCategory.all => 'All',
    WidgetCategory.clocks => 'Clocks',
    WidgetCategory.music => 'Music',
  };
}
