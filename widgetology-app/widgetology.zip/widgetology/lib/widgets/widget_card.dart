import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/widget_model.dart';
import '../state/widget_store.dart';
import '../theme/app_theme.dart';
import 'digital_clock_widget.dart';
import 'glass_components.dart';

class WidgetCard extends StatelessWidget {
  const WidgetCard({super.key, required this.widget, required this.onTap});

  final WidgetModel widget;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final store = WidgetStoreScope.of(context);
    final accent = widget.cardColor.swatch;

    return PressableScale(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.white, accent.withValues(alpha: 0.10)],
          ),
          border: Border.all(color: AppColors.borderSoft),
          boxShadow: const [
            BoxShadow(
              color: AppColors.shadow,
              blurRadius: 28,
              offset: Offset(0, 16),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(widget.icon, color: accent, size: 28),
                  ),
                  TierBadge(isFree: widget.isFree, price: widget.price),
                ],
              ),
              const SizedBox(height: 18),
              _WidgetPreview(widget: widget, store: store),
              const SizedBox(height: 18),
              Text(
                widget.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.spaceGrotesk(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                widget.subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  StarRating(rating: widget.rating, count: widget.reviewCount),
                  Text(
                    widget.category.label,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WidgetPreview extends StatelessWidget {
  const _WidgetPreview({required this.widget, required this.store});

  final WidgetModel widget;
  final WidgetStore store;

  @override
  Widget build(BuildContext context) {
    return DigitalClockWidgetPreview(
      accent: store.clockColor.swatch,
      use24HourClock: store.use24HourClock,
      compactLayout: true,
      style: store.clockStyle,
      showSeconds: false,
      padding: const EdgeInsets.all(16),
    );
  }
}
