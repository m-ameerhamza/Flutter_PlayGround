import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/widget_model.dart';
import '../theme/app_theme.dart';
import 'glass_components.dart';

class DigitalClockWidgetPreview extends StatelessWidget {
  const DigitalClockWidgetPreview({
    super.key,
    required this.accent,
    required this.use24HourClock,
    required this.compactLayout,
    required this.style,
    this.padding = const EdgeInsets.all(20),
    this.showSeconds = true,
  });

  final Color accent;
  final bool use24HourClock;
  final bool compactLayout;
  final ClockVisualStyle style;
  final EdgeInsetsGeometry padding;
  final bool showSeconds;

  @override
  Widget build(BuildContext context) {
    final gradient = switch (style) {
      ClockVisualStyle.soft => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Colors.white, accent.withValues(alpha: 0.16)],
      ),
      ClockVisualStyle.bold => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [accent, accent.withValues(alpha: 0.78)],
      ),
    };
    final primaryText = style == ClockVisualStyle.bold
        ? Colors.white
        : AppColors.textPrimary;
    final secondaryText = style == ClockVisualStyle.bold
        ? Colors.white.withValues(alpha: 0.74)
        : AppColors.textSecondary;

    return GlassBox(
      gradient: gradient,
      padding: padding,
      borderRadius: compactLayout ? 26 : 30,
      borderColor: accent.withValues(alpha: 0.18),
      child: StreamBuilder<DateTime>(
        stream: Stream<DateTime>.periodic(
          const Duration(seconds: 1),
          (_) => DateTime.now(),
        ),
        initialData: DateTime.now(),
        builder: (context, snapshot) {
          final now = snapshot.data ?? DateTime.now();
          final time = _formatTime(now, use24HourClock, showSeconds);
          final date =
              '${_weekday(now.weekday)}, ${_month(now.month)} ${now.day}';

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.access_time_filled_rounded,
                    size: 18,
                    color: primaryText,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      compactLayout ? 'Compact Clock' : 'Digital Clock Widget',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: secondaryText,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: compactLayout ? 14 : 18),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  time,
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: compactLayout ? 40 : 54,
                    fontWeight: FontWeight.w700,
                    color: primaryText,
                    height: 1,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                date,
                style: Theme.of(
                  context,
                ).textTheme.bodyMedium?.copyWith(color: secondaryText),
              ),
              SizedBox(height: compactLayout ? 14 : 18),
              Container(
                width: double.infinity,
                height: compactLayout ? 8 : 10,
                decoration: BoxDecoration(
                  color: style == ClockVisualStyle.bold
                      ? Colors.white.withValues(alpha: 0.18)
                      : accent.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  String _formatTime(DateTime now, bool use24HourClock, bool showSeconds) {
    final hourValue = use24HourClock ? now.hour : ((now.hour + 11) % 12) + 1;
    final hour = hourValue.toString().padLeft(2, '0');
    final minute = now.minute.toString().padLeft(2, '0');
    final second = now.second.toString().padLeft(2, '0');

    if (use24HourClock) {
      return showSeconds ? '$hour:$minute:$second' : '$hour:$minute';
    }

    final meridiem = now.hour >= 12 ? 'PM' : 'AM';
    return showSeconds
        ? '$hour:$minute:$second $meridiem'
        : '$hour:$minute $meridiem';
  }

  String _weekday(int value) => switch (value) {
    1 => 'Monday',
    2 => 'Tuesday',
    3 => 'Wednesday',
    4 => 'Thursday',
    5 => 'Friday',
    6 => 'Saturday',
    _ => 'Sunday',
  };

  String _month(int value) => switch (value) {
    1 => 'Jan',
    2 => 'Feb',
    3 => 'Mar',
    4 => 'Apr',
    5 => 'May',
    6 => 'Jun',
    7 => 'Jul',
    8 => 'Aug',
    9 => 'Sep',
    10 => 'Oct',
    11 => 'Nov',
    _ => 'Dec',
  };
}
