import 'dart:io';

import 'package:flutter/services.dart';

import '../models/widget_model.dart';

class AndroidWidgetService {
  static const MethodChannel _channel = MethodChannel('widgetology/home_widget');

  /// Legacy - use syncAllWidgets for multi-widget support
  static Future<void> syncDigitalClock({
    required bool use24HourClock,
    required bool compactLayout,
    required ClockVisualStyle style,
    required WidgetCardColor color,
  }) async {
    final configs = {'digital_clock': {
      'use24HourClock': use24HourClock,
      'compactLayout': compactLayout,
      'style': style.name,
      'color': color.name,
      'type': 'clock',
    }};
    await syncAllWidgets(configs);
  }

  /// Sync configs for all home screen widgets
  static Future<void> syncAllWidgets(Map<String, Map<String, dynamic>> configs) async {
    if (!Platform.isAndroid) return;

    try {
      await _channel.invokeMethod<void>('syncAllWidgets', {'configs': configs});
    } on MissingPluginException {
      // Plugin not available - silently fail
    } catch (e) {
      // Other errors - silently fail
    }
  }

  /// Legacy - use pinWidget(String widgetId)
  static Future<bool> pinDigitalClock() async {
    return pinWidget('digital_clock');
  }

  /// Pin generic widget to home screen
  static Future<bool> pinWidget(String widgetId) async {
    if (!Platform.isAndroid) return false;

    try {
      final result = await _channel.invokeMethod<bool>('pinWidget', {'widgetId': widgetId});
      return result ?? false;
    } on MissingPluginException {
      return false;
    } catch (e) {
      return false;
    }
  }
}

