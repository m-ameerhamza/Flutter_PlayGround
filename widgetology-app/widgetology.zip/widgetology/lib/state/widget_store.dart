import 'dart:async';

import 'package:flutter/material.dart';

import '../models/widget_model.dart';
import '../services/android_widget_service.dart';

class WidgetStore extends ChangeNotifier {
  final Set<String> _downloadedWidgetIds = <String>{};
  final Set<String> _purchasedWidgetIds = <String>{};
  final List<String> _homeWidgetIds = <String>[];
  final Map<String, Map<String, dynamic>> _widgetConfigs = {};

  bool _use24HourClock = false;
  bool _compactClockLayout = false;
  WidgetCardColor _clockColor = WidgetCardColor.navy;
  ClockVisualStyle _clockStyle = ClockVisualStyle.soft;

  WidgetStore() {
    _syncAllAndroidWidgets();
  }

  List<WidgetModel> get allWidgets => kWidgets;
  List<WidgetModel> get downloadedWidgets =>
      widgetsFromIds(_downloadedWidgetIds);
  List<WidgetModel> get purchasedWidgets => widgetsFromIds(_purchasedWidgetIds);
  List<WidgetModel> get homeWidgets => _homeWidgetIds
      .map((id) => kWidgets.firstWhere((widget) => widget.id == id))
      .toList();

  bool get use24HourClock => _use24HourClock;
  bool get compactClockLayout => _compactClockLayout;
  WidgetCardColor get clockColor => _clockColor;
  ClockVisualStyle get clockStyle => _clockStyle;

  bool isDownloaded(String widgetId) => _downloadedWidgetIds.contains(widgetId);
  bool isPurchased(String widgetId) => _purchasedWidgetIds.contains(widgetId);
  bool isAddedToHome(String widgetId) => _homeWidgetIds.contains(widgetId);

  void installWidget(WidgetModel widget) {
    _downloadedWidgetIds.add(widget.id);
    notifyListeners();
    _syncAllAndroidWidgets();
  }

  void purchaseWidget(WidgetModel widget) {
    _purchasedWidgetIds.add(widget.id);
    _downloadedWidgetIds.add(widget.id);
    notifyListeners();
    _syncAllAndroidWidgets();
  }

  void addWidgetToHome(WidgetModel widget) {
    if (_homeWidgetIds.contains(widget.id)) return;
    _homeWidgetIds.add(widget.id);
    _downloadedWidgetIds.add(widget.id);
    _widgetConfigs[widget.id] = _defaultConfig(widget.id);
    notifyListeners();
    _syncAllAndroidWidgets();
    unawaited(AndroidWidgetService.pinWidget(widget.id));
  }

  void removeWidgetFromHome(String widgetId) {
    _homeWidgetIds.remove(widgetId);
    _widgetConfigs.remove(widgetId);
    notifyListeners();
    _syncAllAndroidWidgets();
  }

  void setClockFormat(bool use24Hour) {
    if (_use24HourClock == use24Hour) return;
    _use24HourClock = use24Hour;
    if (_widgetConfigs['digital_clock'] != null) {
      _widgetConfigs['digital_clock']!['use24HourClock'] = use24Hour;
    }
    notifyListeners();
    _syncAllAndroidWidgets();
  }

  void setClockColor(WidgetCardColor color) {
    if (_clockColor == color) return;
    _clockColor = color;
    if (_widgetConfigs['digital_clock'] != null) {
      _widgetConfigs['digital_clock']!['color'] = color.name;
    }
    notifyListeners();
    _syncAllAndroidWidgets();
  }

  void setClockStyle(ClockVisualStyle style) {
    if (_clockStyle == style) return;
    _clockStyle = style;
    if (_widgetConfigs['digital_clock'] != null) {
      _widgetConfigs['digital_clock']!['style'] = style.name;
    }
    notifyListeners();
    _syncAllAndroidWidgets();
  }

  void setCompactClockLayout(bool compact) {
    if (_compactClockLayout == compact) return;
    _compactClockLayout = compact;
    if (_widgetConfigs['digital_clock'] != null) {
      _widgetConfigs['digital_clock']!['compactLayout'] = compact;
    }
    notifyListeners();
    _syncAllAndroidWidgets();
  }

  Map<String, Map<String, dynamic>> _buildConfigs() {
    final configs = <String, Map<String, dynamic>>{};
    for (final id in _homeWidgetIds) {
      configs[id] = _widgetConfigs[id] ?? _defaultConfig(id);
    }
    return configs;
  }

  Map<String, dynamic> _defaultConfig(String id) {
    final model = kWidgets.firstWhere((w) => w.id == id);
    return {
      'type': switch(id) {
        'digital_clock' => 'clock',
        'battery' => 'battery',
        'weather' => 'weather',
        'music' => 'music',
        _ => 'generic',
      },
      'color': model.cardColor.name,
      'compact': false,
    };
  }

  void _syncAllAndroidWidgets() {
    unawaited(AndroidWidgetService.syncAllWidgets(_buildConfigs()));
  }
}

class WidgetStoreScope extends InheritedNotifier<WidgetStore> {
  const WidgetStoreScope({
    super.key,
    required WidgetStore store,
    required super.child,
  }) : super(notifier: store);

  static WidgetStore of(BuildContext context) {
    final scope = context
        .dependOnInheritedWidgetOfExactType<WidgetStoreScope>();
    assert(scope != null, 'WidgetStoreScope not found in context');
    return scope!.notifier!;
  }
}
