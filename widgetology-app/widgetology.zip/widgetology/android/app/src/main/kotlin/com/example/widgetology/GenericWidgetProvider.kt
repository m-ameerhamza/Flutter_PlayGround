package com.example.widgetology

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import android.os.Build

class GenericWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { widgetId ->
            updateAppWidget(context, appWidgetManager, widgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (
            intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED ||
            intent.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE
        ) {
            updateAllWidgets(context)
        }
    }

    companion object {
        const val PREFS_NAME = "widgetology_widgets"
        const val KEY_CONFIG_PREFIX = "config_"

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, GenericWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
            appWidgetIds.forEach { widgetId ->
                updateAppWidget(context, appWidgetManager, widgetId)
            }
        }

        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val configKey = "${KEY_CONFIG_PREFIX}$appWidgetId"
            val configJson = prefs.getString(configKey, null)
            if (configJson == null) {
                // Default empty widget
                val views = RemoteViews(context.packageName, R.layout.generic_widget)
                views.setTextViewText(R.id.widget_title, "Widgetology")
                views.setTextViewText(R.id.widget_content, "Problem Loading Widget")
            views.setViewVisibility(R.id.widget_accent, android.view.View.GONE)
                appWidgetManager.updateAppWidget(appWidgetId, views)
                return
            }

            // Parse config (simple JSON or map)
            val type = prefs.getString("$configKey.type", "generic") ?: "generic"
            val colorName = prefs.getString("$configKey.color", "navy") ?: "navy"
            val compact = prefs.getBoolean("$configKey.compact", false)
            val accentColor = resolveAccentColor(colorName)

            val views = RemoteViews(context.packageName, R.layout.generic_widget)
            views.setInt(R.id.widget_root, "setBackgroundColor", Color.parseColor("#FFF7F0"))
            views.setInt(R.id.widget_accent, "setBackgroundColor", accentColor)
            views.setViewPadding(R.id.widget_root, dp(context, if (compact) 16 else 20), 0, 0, 0)

            when (type) {
                "clock" -> {
                    views.setTextViewText(R.id.widget_title, "Digital Clock")
                    views.setInt(R.id.widget_time, "setTextColor", Color.parseColor("#1F2A37"))
                    views.setFloat(R.id.widget_time, "setTextSize", if (compact) 28f else 34f)
                }

                "weather" -> {
                    views.setTextViewText(R.id.widget_title, "Weather")
                    views.setTextViewText(R.id.widget_content, "22° Cloudy")
                    views.setInt(R.id.widget_content, "setTextColor", Color.parseColor("#1F2A37"))
                }
                "battery" -> {
                    views.setTextViewText(R.id.widget_title, "Battery")
                    views.setTextViewText(R.id.widget_content, "87% Charging")
                    views.setInt(R.id.widget_content, "setTextColor", Color.parseColor("#1F2A37"))
                }
                "music" -> {
                    views.setTextViewText(R.id.widget_title, "Music")
                    views.setTextViewText(R.id.widget_content, "Good Vibes")
                    views.setInt(R.id.widget_content, "setTextColor", Color.parseColor("#1F2A37"))
                }
                else -> {
                    views.setTextViewText(R.id.widget_title, "Widgetology")
                    views.setTextViewText(R.id.widget_content, "Tap to open")
                }
            }

            val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            val pendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun resolveAccentColor(colorName: String): Int {
            return when (colorName) {
                "terracotta" -> Color.parseColor("#C8643B")
                "gold" -> Color.parseColor("#DBA94C")
                "sage" -> Color.parseColor("#6E8B6B")
                "rose" -> Color.parseColor("#BD6C7A")
                "sky" -> Color.parseColor("#7CA6C7")
                else -> Color.parseColor("#1E3A5F")
            }
        }

        private fun dp(context: Context, value: Int): Int {
            return TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value.toFloat(),
                context.resources.displayMetrics
            ).toInt()
        }
    }
}

