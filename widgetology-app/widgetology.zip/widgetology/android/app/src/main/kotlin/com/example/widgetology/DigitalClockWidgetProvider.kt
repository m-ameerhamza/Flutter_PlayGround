package com.example.widgetology

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.TypedValue
import android.widget.RemoteViews

class DigitalClockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { widgetId ->
            updateAppWidget(context, appWidgetManager, widgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (
            intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED ||
            intent.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE
        ) {
            updateAllWidgets(context)
        }
    }

    companion object {
        const val PREFS_NAME = "widgetology_home_widget"
        const val KEY_USE_24_HOUR = "use24HourClock"
        const val KEY_COMPACT_LAYOUT = "compactLayout"
        const val KEY_STYLE = "style"
        const val KEY_COLOR = "color"

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, DigitalClockWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
            appWidgetIds.forEach { widgetId ->
                updateAppWidget(context, appWidgetManager, widgetId)
            }
        }

        private fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val use24HourClock = prefs.getBoolean(KEY_USE_24_HOUR, false)
            val compactLayout = prefs.getBoolean(KEY_COMPACT_LAYOUT, false)
            val style = prefs.getString(KEY_STYLE, "soft") ?: "soft"
            val colorName = prefs.getString(KEY_COLOR, "navy") ?: "navy"
            val accentColor = resolveAccentColor(colorName)

            val isBold = style == "bold"
            val backgroundColor = if (isBold) accentColor else Color.parseColor("#FFF7F0")
            val primaryTextColor = if (isBold) Color.WHITE else Color.parseColor("#1F2A37")
            val secondaryTextColor = if (isBold) Color.parseColor("#D9FFFFFF") else Color.parseColor("#5D6B79")

            val views = RemoteViews(context.packageName, R.layout.digital_clock_widget)
            views.setInt(R.id.widget_root, "setBackgroundColor", backgroundColor)
            views.setInt(R.id.widget_accent, "setBackgroundColor", accentColor)
            views.setTextColor(R.id.widget_label, secondaryTextColor)
            views.setTextColor(R.id.widget_time, primaryTextColor)
            views.setTextColor(R.id.widget_date, secondaryTextColor)
            views.setTextViewText(R.id.widget_label, if (compactLayout) "Compact Clock" else "Digital Clock")
            views.setFloat(
                R.id.widget_time,
                "setTextSize",
                if (compactLayout) 28f else 34f
            )
            views.setFloat(
                R.id.widget_date,
                "setTextSize",
                if (compactLayout) 12f else 14f
            )
            views.setViewPadding(
                R.id.widget_root,
                dp(context, if (compactLayout) 16 else 20),
                dp(context, if (compactLayout) 16 else 20),
                dp(context, if (compactLayout) 16 else 20),
                dp(context, if (compactLayout) 16 else 20)
            )

            val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)

            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun resolveAccentColor(colorName: String): Int {
            return when (colorName) {
                "terracotta" -> Color.parseColor("#C8643B")
                "gold" -> Color.parseColor("#DBA94C")
                "sage" -> Color.parseColor("#6E8B6B")
                "rose" -> Color.parseColor("#BD6C7A")
                "sky" -> Color.parseColor("#7CA6C7")
                else -> Color.parseColor("#1E3A5F")
            }
        }

        private fun dp(context: Context, value: Int): Int {
            return TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value.toFloat(),
                context.resources.displayMetrics
            ).toInt()
        }
    }
}
