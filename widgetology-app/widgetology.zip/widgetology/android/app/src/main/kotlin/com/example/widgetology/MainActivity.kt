package com.example.widgetology

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.SharedPreferences
import android.os.Build
import com.google.gson.Gson
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.content.Context


class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "widgetology/home_widget"
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "syncAllWidgets" -> {
                    val configs = call.argument<Map<String, Any>>("configs") ?: emptyMap()
                    val prefs = getSharedPreferences(GenericWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
                    configs.forEach { (widgetId, config) ->
                        prefs.edit()
                            .putString(GenericWidgetProvider.KEY_CONFIG_PREFIX + widgetId, Gson().toJson(config))
                            .apply()
                    }
                    GenericWidgetProvider.updateAllWidgets(this)
                    result.success(null)
                }


                "pinWidget" -> {
                    val widgetId = call.argument<String>("widgetId") ?: return@setMethodCallHandler result.notImplemented()
                    result.success(pinWidget(widgetId))
                }

                "syncDigitalClock" -> {
                    val use24HourClock = call.argument<Boolean>("use24HourClock") ?: false
                    val compactLayout = call.argument<Boolean>("compactLayout") ?: false
                    val style = call.argument<String>("style") ?: "soft"
                    val color = call.argument<String>("color") ?: "navy"

                    val configs = mapOf("digital_clock" to mapOf(
                        "use24HourClock" to use24HourClock,
                        "compactLayout" to compactLayout,
                        "style" to style,
                        "color" to color,
                        "type" to "clock"
                    ))
                    val prefs = getSharedPreferences(GenericWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
                    prefs.edit()
                        .putString(GenericWidgetProvider.KEY_CONFIG_PREFIX + "digital_clock", Gson().toJson(configs["digital_clock"]!!))
                        .apply()
                    GenericWidgetProvider.updateAllWidgets(this)
                    result.success(null)
                }


"pinDigitalClock" -> {
                    result.success(pinDigitalClockWidget("digital_clock"))
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun pinWidget(widgetId: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return false
        }

        val appWidgetManager = getSystemService(AppWidgetManager::class.java) ?: return false
        if (!appWidgetManager.isRequestPinAppWidgetSupported) {
            return false
        }

        val provider = ComponentName(this, GenericWidgetProvider::class.java)
        return appWidgetManager.requestPinAppWidget(provider, null, null)
    }

    private fun pinDigitalClockWidget(widgetId: String = "digital_clock"): Boolean = pinWidget(widgetId)
}
