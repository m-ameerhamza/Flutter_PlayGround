package com.example.payfull_walletapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
